package com.example.demo.company.worker.workerAspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.util.Date;


@Aspect
@Component
public class LoggingAspect {
    //private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    //Pointcut expression

    @Before(value =  "execution(* com.example.demo.company.worker.workerController.WorkerController.*(..))")
    public void logBefore(JoinPoint joinPoint) {
        //logger.info("Entering: " + joinPoint.getSignature());
        System.out.println("Request to "+ joinPoint.getSignature() + "started at  " + new Date());
    }

    @After("execution(* com.example.demo.company.worker.workerController.WorkerController.*(..))")
    public void logAfter(JoinPoint joinPoint) {
       // logger.info("Exiting: " + joinPoint.getSignature() + " with result: " + result);
        System.out.println("Request to "+ joinPoint.getSignature() + "ended at  " + new Date());
    }
}