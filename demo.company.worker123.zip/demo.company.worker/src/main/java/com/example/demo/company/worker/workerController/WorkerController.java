package com.example.demo.company.worker.workerController;

import com.example.demo.company.worker.workerEntity.Worker;
import com.example.demo.company.worker.workerService.WorkerService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/workers")
    public class WorkerController {
    @Autowired
    private WorkerService workerService;

    @Transactional
    @GetMapping
    public List<Worker> getAllWorkers() {
        return workerService.getAllWorkers();
    }

    @PostMapping
    public Worker createWorker(@RequestBody Worker worker) {
        return workerService.createWorker(worker);
    }

    @PostMapping("/bulk")
    public List<Worker> createWorkers(@RequestBody List<Worker> workers) {
        return workerService.createWorkers(workers);
    }

    // Additional endpoints for update and delete can be added here

    @GetMapping("/{id}")
    public Optional<Worker> getWorkerById(@PathVariable Long id) {
        return workerService.getWorkerById(id);
    }

    @PutMapping("/{id}")
    public Worker updateWorker(@PathVariable Long id, @RequestBody Worker updatedWorker) {
        return workerService.updateWorker(id, updatedWorker);
    }

    @DeleteMapping("/{id}")
    public String deleteWorker(@PathVariable Long id) {
        if (workerService.deleteWorker(id)) {
            return "Worker with ID " + id + " deleted successfully.";
        } else {
            return "Worker with ID " + id + " not found.";
        }
    }
}
