package com.example.demo.company.worker.workerService;

import com.example.demo.company.worker.workerEntity.Worker;
import com.example.demo.company.worker.workerRepo.WorkerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WorkerService {
    @Autowired
    private WorkerRepository workerRepository;

    public List<Worker> getAllWorkers() {
        return workerRepository.findAll();
    }

    public Worker createWorker(Worker worker) {
        return workerRepository.save(worker);
    }

    public List<Worker> createWorkers(List<Worker> workers) {
        return workerRepository.saveAll(workers);
    }

    // Additional methods for update and delete can be added here

    public Optional<Worker> getWorkerById(Long id) {
        return workerRepository.findById(id);
    }

    public Worker updateWorker(Long id, Worker updatedWorker) {
        if (workerRepository.existsById(id)) {
            updatedWorker.setId(id); // Ensure the ID is set for the update
            return workerRepository.save(updatedWorker);
        }
        return null; // Or throw an exception
    }

    public boolean deleteWorker(Long id) {
        if (workerRepository.existsById(id)) {
            workerRepository.deleteById(id);
            return true;
        }
        return false; // Or throw an exception
    }
}
