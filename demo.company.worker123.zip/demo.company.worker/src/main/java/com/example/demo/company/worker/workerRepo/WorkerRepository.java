package com.example.demo.company.worker.workerRepo;

import com.example.demo.company.worker.workerEntity.Worker;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkerRepository extends JpaRepository<Worker, Long> {
}
