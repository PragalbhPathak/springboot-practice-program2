package com.example.SpringSecurityDemo.controller;


import com.example.SpringSecurityDemo.entity.User;
import com.example.SpringSecurityDemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

//@RestController
//@RequestMapping("/user")
//public class UserController {
//
//    @GetMapping("/profile")
//    public ResponseEntity<String> getUserProfile() {
//        return ResponseEntity.ok("User Profile");
//    }
//}
//
//@RestController
//@RequestMapping("/user")
//public class UserController {
//
//    @Autowired
//    private UserService userService;
//
//    @PostMapping("/register")
//    public ResponseEntity<User> registerUser(@RequestBody User user) {
//        User registeredUser = userService.registerUser(user);
//        return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
//    }
//
//    @GetMapping("/profile")
//    public ResponseEntity<String> getUserProfile() {
//        // Logic to fetch user profile
//        return ResponseEntity.ok("User Profile");
//    }
//}
//


@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User registeredUser = userService.registerUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
    }

    @GetMapping("/profile")
    public ResponseEntity<String> getUserProfile() {
        // Logic to fetch user profile
        return ResponseEntity.ok("User Profile");
    }
}
