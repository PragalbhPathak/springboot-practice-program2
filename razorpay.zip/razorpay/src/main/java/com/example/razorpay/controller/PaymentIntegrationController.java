package com.example.razorpay.controller;

import com.example.razorpay.util.RazorpaySignatureUtil;
import com.example.razorpay.entity.PaymentLog;
import com.example.razorpay.repository.PaymentLogRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
public class PaymentIntegrationController {

    @Value("${rzp_key_id}")
    private String razorpayKeyId;

    @Value("${rzp_key_secret}")
    private String razorpayKeySecret;

    @Value("${rzp_currency}")
    private String currency;

    @Value("${rzp_company_name}")
    private String companyName;

    @Autowired
    PaymentLogRepository paymentLogRepository;

    @PostMapping("/createOrder")
    public Map<String, Object> createOrder(@RequestParam("amount") int amount) {
        Map<String, Object> response = new HashMap<>();
        try {
            RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amount * 100); // amount in paise
            orderRequest.put("currency", currency);
            orderRequest.put("receipt", "txn_" + System.currentTimeMillis());

            Order order = razorpay.orders.create(orderRequest);

            response.put("id", order.get("id"));
            response.put("companyName", companyName);
            response.put("currency", order.get("currency"));
            response.put("amount", order.get("amount"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    @PostMapping("/verifyPayment")
    public Map<String, Object> verifyPayment(
            @RequestParam("razorpay_order_id") String orderId,
            @RequestParam("razorpay_payment_id") String paymentId,
            @RequestParam("razorpay_signature") String signature
    ) throws RazorpayException {
        Map<String, Object> response = new HashMap<>();

        boolean isValid = RazorpaySignatureUtil.verifySignature(orderId, paymentId, signature, razorpayKeySecret);

        RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
        com.razorpay.Payment payment = razorpay.payments.fetch(paymentId);

        int amount = Integer.parseInt(payment.get("amount").toString()); // paise
        String currency = payment.get("currency").toString();
        String method = payment.get("method").toString();
        String status = payment.get("status").toString();

        PaymentLog log = new PaymentLog();
        log.setOrderId(orderId);
        log.setPaymentId(paymentId);
        log.setSignature(signature);
        log.setVerified(isValid);
        log.setAmount(amount/100);
        log.setCurrency(currency);
        log.setMethod(method);
        log.setStatus(status);
        paymentLogRepository.save(log);

        response.put("success", isValid);
        response.put("amount", amount);
        response.put("currency", currency);
        response.put("status", status);
        return response;
    }
}
