package com.example.razorpay.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "payment_log")
public class PaymentLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @Column(name = "order_id")
    private String orderId;
    @Column(name = "payment_id")
    private String paymentId;
    @Column(name = "signature")
    private String signature;
    @Column(name = "verified")
    private boolean verified;
    @Column(name = "timestamp")
    private LocalDateTime timestamp = LocalDateTime.now();
    @Column(name = "amount")
    private Integer amount;
    @Column(name = "currency")
    private String currency;
    @Column(name = "method")
    private String method;
    @Column(name = "status")
    private String status;

}
