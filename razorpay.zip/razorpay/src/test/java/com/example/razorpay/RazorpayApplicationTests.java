package com.example.razorpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RazorpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
