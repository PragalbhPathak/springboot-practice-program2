package com.example.demo.practiceJwt.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class ManageOrders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long mId;
    private Long autoId;  // Reference to orderId (Foreign Key)
    private Long productId; // Reference to productId (Foreign Key)

}


