package com.example.demo.practiceJwt.implementation;

import com.example.demo.practiceJwt.dto.AuthRequest;
import com.example.demo.practiceJwt.dto.BaseApiResponse;
import com.example.demo.practiceJwt.dto.UserRequest;

public interface UserServiceImpl {
    BaseApiResponse createUser(UserRequest userRequest);
    BaseApiResponse userLogin(AuthRequest authRequest);
}
