//package com.example.demo.practiceJwt.service;
//
//import java.util.Collections;
//import java.util.List;
//import java.util.concurrent.Callable;
//
//public class CircuitBreaker {
//
//    private static final int FAILURE_THRESHOLD = 10; // Number of failures before opening the circuit
//    private static final long RECOVERY_TIMEOUT = 4000; // Time (in ms) before attempting recovery (half-open state)
//    private static final int SUCCESS_THRESHOLD = 5; // Number of successful attempts to close the circuit
//
//    private int failureCount = 0;
//    private int successCount = 0;
//    private long lastFailureTime = 0;
//    private String state = "CLOSED"; // States: CLOSED, OPEN, HALF_OPEN
//
//    public synchronized <T> List<T> call(Callable<List<T>> serviceCall) {
//
//        if (state.equals("OPEN") && (System.currentTimeMillis() - lastFailureTime) > RECOVERY_TIMEOUT) {
//            state = "HALF_OPEN";  // Attempt recovery
//        }
//
//        if (state.equals("OPEN")) {
//            // If the circuit is OPEN, skip the service call and return a fallback response
//            System.out.println("Circuit is OPEN, request is denied.");
//            return Collections.emptyList();
//        }
//
//        try {
//            List<T> result = serviceCall.call();
//
//            if (state.equals("HALF_OPEN")) {
//                successCount++;
//                if (successCount >= SUCCESS_THRESHOLD) {
//                    state = "CLOSED";  // If the service is working, close the circuit
//                }
//            }
//
//            failureCount = 0;  // Reset failure count on success
//            return result;
//        } catch (Exception e) {
//            failureCount++;
//            if (failureCount >= FAILURE_THRESHOLD) {
//                state = "OPEN";  // Open the circuit after too many failures
//                lastFailureTime = System.currentTimeMillis();
//            }
//            System.out.println("Service call failed: " + e.getMessage());
//            return Collections.emptyList();  // Fallback response on failure
//        }
//    }
//
//    public void reset() {
//        failureCount = 0;
//        successCount = 0;
//        state = "CLOSED";
//        System.out.println("Circuit breaker reset.");
//    }
//
//    public String getState() {
//        return state;
//    }
//}
