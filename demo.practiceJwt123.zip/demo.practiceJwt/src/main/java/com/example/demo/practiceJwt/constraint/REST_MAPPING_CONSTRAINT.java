package com.example.demo.practiceJwt.constraint;

public interface REST_MAPPING_CONSTRAINT {
    String BASE_URL = "/api/user";

    interface DEFINED_API{
        String CREATE_USER = "/create";
        String GET_USER = "/get";
        String LOGIN_USER = "/login";

        String CREATE_PRODUCT = "/createProduct";
        String GET_PRODUCT_BY_ID = "/getProduct";
        String GET_PRODUCTS = "/getProducts";

        String CREATE_ORDER = "/createOrder";
        String GET_ORDER_BY_ID = "/getOrder";
        String GET_ORDERS = "/getOrders";
    }
    interface STATUS_CODES{
        String INTERNAL_SERVER_ERROR="500";
        String SUCCESS_OK="200";
        String SUCCESSFULLY_CREATED = "201";
        String  PARTIAL_STATUS="207";
        String BAD_REQUEST= "400";
        String UNAUTHORIZED = "401";
        String FORBIDDEN = "403";
        String NOT_FOUND ="404";
    }
    interface SUCCESS_STATUS{
        int SUCCESS = 1;
        int FAILURE = 0;
    }

    interface COMMON_MESSAGE{
        String MESSAGE_CREATE = "Created Successfully";
        String MESSAGE_UPDATE = "Update Successfully";
        String MESSAGE_SAVE = "Data Saved Successfully";
        String MESSAGE_INVALID_CREDENTIALS = "Invalid Credentials";
        String MESSAGE_COMMON_SERVER_ERROR = "Something went wrong";
        String MESSAGE_NOT_FOUND = "Data not found";
        String MESSAGE_FIELD_REQUIRED = "Field is required";
        String MESSAGE_FETCH_DATA = "Data fetched Successfully";
        String MESSAGE_UNAUTHORIZED = "Access Denied";

    }
}
