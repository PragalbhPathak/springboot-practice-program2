package com.example.demo.practiceJwt.repository;

import com.example.demo.practiceJwt.entity.Orders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Orders,Long> {

    Optional<Orders> findById(Long orderId);
    List<Orders> findAll();
}
