package com.example.demo.practiceJwt.repository;

import com.example.demo.practiceJwt.entity.ManageOrders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ManageOrdersRepository extends JpaRepository<ManageOrders, Long> {
//    @Query(value = "SELECT mo.productId FROM ManageOrders mo WHERE mo.orderId = :orderId" ,nativeQuery = true)
//    List<Long> findProductIdsByOrderId(Long orderId);
}
