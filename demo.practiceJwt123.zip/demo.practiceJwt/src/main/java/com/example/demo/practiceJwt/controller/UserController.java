package com.example.demo.practiceJwt.controller;

import com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT;
import com.example.demo.practiceJwt.dto.AuthRequest;
import com.example.demo.practiceJwt.dto.BaseApiResponse;
import com.example.demo.practiceJwt.dto.UserRequest;
import com.example.demo.practiceJwt.dto.UserResponse;
import com.example.demo.practiceJwt.entity.User;
import com.example.demo.practiceJwt.implementation.UserServiceImpl;
import com.example.demo.practiceJwt.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.BASE_URL;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.COMMON_MESSAGE.MESSAGE_COMMON_SERVER_ERROR;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.COMMON_MESSAGE.MESSAGE_FETCH_DATA;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.STATUS_CODES.*;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.SUCCESS_STATUS.FAILURE;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.SUCCESS_STATUS.SUCCESS;

@RestController
@RequestMapping(BASE_URL)
public class UserController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.CREATE_USER)
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<BaseApiResponse> createUser(@RequestBody UserRequest userRequest) {
        try {
            BaseApiResponse baseApiResponse = userServiceImpl.createUser(userRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(baseApiResponse);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new BaseApiResponse(INTERNAL_SERVER_ERROR, FAILURE, MESSAGE_COMMON_SERVER_ERROR, null));
        }
    }

    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.LOGIN_USER)
    public ResponseEntity<BaseApiResponse> login(@RequestBody AuthRequest authRequest) {
        try {
            BaseApiResponse response = userServiceImpl.userLogin(authRequest);
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new BaseApiResponse(INTERNAL_SERVER_ERROR, FAILURE, MESSAGE_COMMON_SERVER_ERROR, null));
        }
    }

}
