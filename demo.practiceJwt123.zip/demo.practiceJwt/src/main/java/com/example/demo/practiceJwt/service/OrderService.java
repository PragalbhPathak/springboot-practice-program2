package com.example.demo.practiceJwt.service;

import com.example.demo.practiceJwt.dto.OrderRequest;
import com.example.demo.practiceJwt.entity.ManageOrders;
import com.example.demo.practiceJwt.entity.Orders;
import com.example.demo.practiceJwt.entity.Product;
import com.example.demo.practiceJwt.repository.OrderRepository;
import com.example.demo.practiceJwt.repository.ProductRepository;
import com.example.demo.practiceJwt.repository.ManageOrdersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ManageOrdersRepository manageOrdersRepository;


//    public Orders createOrder(OrderRequest orderRequest) {
//        Orders order = new Orders();
//        order.setUserId(orderRequest.getUserId());
//
//        // Set the order date (default to current date if null)
//        order.setOrderDate(orderRequest.getOrderDate() != null ? orderRequest.getOrderDate() : new Date());
//
//        // Fetch the products based on productIds
//        List<Product> products = productRepository.findAllById(orderRequest.getProductIds());
//
//        // Set the products in the order
//        order.setProducts(products);
//
//        // Save and return the order
//        return orderRepository.save(order);
//    }

    public Orders createOrder(OrderRequest orderRequest) {
        // Step 1: Create the Orders entity
        Orders order = new Orders();
        order.setUserId(orderRequest.getUserId());
        order.setOrderDate(orderRequest.getOrderDate() != null ? orderRequest.getOrderDate() : new Date());
        order.setOrderId(generateRandomString(10));
        order = orderRepository.save(order);

        List<ManageOrders> manageOrdersList = new ArrayList<>();

        for (Long productId : orderRequest.getProductIds()) {

            ManageOrders manageOrder = new ManageOrders();
            manageOrder.setAutoId(order.getAutoId());   // Set the orderId
            manageOrder.setProductId(productId);// Set the productId
            manageOrdersList.add(manageOrder);

            // Save the relationship manually (no JPA mapping)
           // manageOrdersRepository.save(manageOrder);
        }
        if (!manageOrdersList.isEmpty()) {
            manageOrdersRepository.saveAll(manageOrdersList);
        }

        // Return the saved order object
        return order;
    }

    // Function to generate a random alphanumeric string of a given length
    public static String generateRandomString(int length) {
        // Define the characters that can be used in the string
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        Random random = new Random();
        StringBuilder result = new StringBuilder(length);

        // Generate random characters and append them to the result
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(characters.length());
            result.append(characters.charAt(randomIndex));
        }

        return result.toString();
    }
//    public List<Product> getProductsForOrder(Long orderId) {
//        // Query to fetch products based on the orderId from the ManageOrders table
//        List<Long> productIds = manageOrdersRepository.findProductIdsByOrderId(orderId);
//
//        // Fetch products from ProductRepository using the productIds
//        return productRepository.findAllById(productIds);
//    }

    public Optional<Orders> getOrderById(Long orderId) {
        return orderRepository.findById(orderId);
    }

    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }

}

