package com.example.demo.practiceJwt.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseApiResponse {
    private String status;
    private int success;
    private String message;
    private Object data;

}
