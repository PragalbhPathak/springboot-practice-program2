package com.example.demo.practiceJwt.service;

import com.example.demo.practiceJwt.dto.ProductRequest;
import com.example.demo.practiceJwt.entity.Product;
import com.example.demo.practiceJwt.repository.ProductRepository;
//import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Product createProduct(ProductRequest productRequest) {
        Product product = new Product();
        product.setProductName(productRequest.getProductName());
        product.setPrice(productRequest.getPrice());
        return productRepository.save(product);
    }

    public Optional<Product> getProductById(Long productId) {
        return productRepository.findById(productId);
    }

//    private final CircuitBreaker circuitBreaker = new CircuitBreaker();  // Instantiate CircuitBreaker
//
//    public List<Product> getAllProducts() {
////        simulateServiceCall();
////        System.err.println("Fallback method invoked: " );
//
//        return circuitBreaker.call(this::simulateServiceCall);  // Use the CircuitBreaker to call the service method
//    }

//    public List<Product> getAllProducts() {
//        return productRepository.findAll();
//    }

     //Apply Circuit Breaker to your service method
    @CircuitBreaker(name = "productService", fallbackMethod = "fallbackGetAllProducts")
    public List<Product> getAllProducts() {
        simulateServiceCall();
        return productRepository.findAll();
    }

    private List<Product> simulateServiceCall() {
        if (Math.random() > 0.2) {
            throw new RuntimeException("Service is down!");
        }
        return productRepository.findAll();
    }

    // Fallback method that will be used if the circuit breaker is open or fails
    public List<Product> fallbackGetAllProducts(Throwable t) {

        System.err.println("Fallback method invoked: " + t.getMessage());
        return Collections.emptyList();  // Return a fallback response
    }
}


//http://localhost:9000/#!/home