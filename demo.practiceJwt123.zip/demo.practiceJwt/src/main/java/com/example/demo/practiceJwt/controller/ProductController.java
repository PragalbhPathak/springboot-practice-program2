package com.example.demo.practiceJwt.controller;

import com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT;
import com.example.demo.practiceJwt.dto.BaseApiResponse;
import com.example.demo.practiceJwt.dto.ProductRequest;
import com.example.demo.practiceJwt.entity.Product;
import com.example.demo.practiceJwt.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.BASE_URL;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.STATUS_CODES.*;

@RestController
@RequestMapping(BASE_URL)
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.CREATE_PRODUCT)
    @PreAuthorize("hasRole('Admin')")
    public BaseApiResponse createProduct(@RequestBody ProductRequest productRequest) {

        try {
            return new BaseApiResponse(SUCCESS_OK, 1, "Product Created Successfully", productService.createProduct(productRequest));
        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to create product", Collections.emptyList());
        }
    }

    // Method to fetch a product by ID using POST
    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.GET_PRODUCT_BY_ID)
    public BaseApiResponse getProductById(@RequestBody ProductRequest productRequest) {
        try {
            Optional<Product> product = productService.getProductById(productRequest.getProductId());
            if (product.isPresent()) {
                return new BaseApiResponse(SUCCESS_OK, 1, "Product fetched successfully", product.get());
            } else {
                return new BaseApiResponse(NOT_FOUND, 0, "Product not found", Collections.emptyList());
            }
        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to fetch product", Collections.emptyList());
        }
    }

    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.GET_PRODUCTS)
    public BaseApiResponse getAllProducts() {
        try {
            // Call the service, which now has the circuit breaker applied
            List<Product> products = productService.getAllProducts();

            // If products are empty, it means the circuit was open or the fallback was triggered
            if (products.isEmpty()) {
                return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to fetch products (Circuit is OPEN)", products);
            }

            return new BaseApiResponse(SUCCESS_OK, 1, "Products fetched successfully", products);
        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to fetch products", Collections.emptyList());
        }
    }

    // Method to fetch all products using POST
//    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.GET_PRODUCTS)
//    public BaseApiResponse getAllProducts() {
//        try {
//            List<Product> products = productService.getAllProducts();  // Using List<Product>
//            return new BaseApiResponse(SUCCESS_OK, 1, "Products fetched successfully", products);
//        } catch (Exception e) {
//            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to fetch products", Collections.emptyList());
//        }
//    }
}