package com.example.demo.practiceJwt.service;

import com.example.demo.practiceJwt.dto.AuthRequest;
import com.example.demo.practiceJwt.dto.BaseApiResponse;
import com.example.demo.practiceJwt.dto.UserRequest;
import com.example.demo.practiceJwt.dto.UserResponse;
import com.example.demo.practiceJwt.entity.User;
import com.example.demo.practiceJwt.implementation.UserServiceImpl;
import com.example.demo.practiceJwt.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.COMMON_MESSAGE.*;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.STATUS_CODES.*;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.SUCCESS_STATUS.FAILURE;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.SUCCESS_STATUS.SUCCESS;

@Service
public class UserService implements UserServiceImpl {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public BaseApiResponse createUser(UserRequest userRequest) {
        try {

            if (userRequest.getId() == null || userRequest.getId() == 0) {
                User user = new User();
                user.setUsername(userRequest.getUsername());
                //user.setPassword(userRequest.getPassword());
                user.setPassword(passwordEncoder.encode(userRequest.getPassword()));
                user.setRole(userRequest.getRole());

                user = userRepository.save(user);
                UserResponse userResponse = mapToUserResponse(user);

                return new BaseApiResponse(SUCCESS_OK, SUCCESS, MESSAGE_SAVE, userResponse);
            }
            return new BaseApiResponse("400", 0, "Data not create", null);

        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, FAILURE, e.getMessage(), Collections.emptyList());
        }
    }

    private UserResponse mapToUserResponse(User user) {
        UserResponse userResponse = new UserResponse();
        userResponse.setId(user.getId());
        userResponse.setUsername(user.getUsername());
        userResponse.setRole(user.getRole());
        return userResponse;
    }

    public BaseApiResponse userLogin(AuthRequest authRequest) {

        String username = authRequest.getUsername();
        String password = authRequest.getPassword();
        String requestedRole = authRequest.getRole();

        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();

            if (passwordEncoder.matches(password, user.getPassword())) {

                if (user.getRole().equals(requestedRole)) {
                    // If roles match, generate the JWT token
                    String token = jwtService.generateToken(user.getUsername(), user.getRole());

                    return new BaseApiResponse(SUCCESS_OK, SUCCESS, "Login successful", token);
                } else {
                    // If the role doesn't match, return an unauthorized response
                    return new BaseApiResponse(BAD_REQUEST, FAILURE, "Role mismatch", Collections.emptyList());
                }
            } else {
                return new BaseApiResponse(BAD_REQUEST, FAILURE, MESSAGE_INVALID_CREDENTIALS, Collections.emptyList());
            }
        } else {
            return new BaseApiResponse(NOT_FOUND, FAILURE, MESSAGE_NOT_FOUND, Collections.emptyList());
        }
    }

}
