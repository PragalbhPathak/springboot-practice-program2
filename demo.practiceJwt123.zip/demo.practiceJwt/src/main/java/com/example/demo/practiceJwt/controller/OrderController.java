package com.example.demo.practiceJwt.controller;

import com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT;
import com.example.demo.practiceJwt.dto.BaseApiResponse;
import com.example.demo.practiceJwt.dto.OrderRequest;
import com.example.demo.practiceJwt.entity.Orders;
import com.example.demo.practiceJwt.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.BASE_URL;
import static com.example.demo.practiceJwt.constraint.REST_MAPPING_CONSTRAINT.STATUS_CODES.*;

@RestController
@RequestMapping(BASE_URL)
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.CREATE_ORDER)
    @PreAuthorize("hasRole('Admin')")
    public BaseApiResponse createOrder(@RequestBody OrderRequest orderRequest) {
        try {
            System.out.println("product id---------------"+orderRequest.getProductIds());
            Orders order = orderService.createOrder(orderRequest);
            return new BaseApiResponse(SUCCESS_OK, 1, "Order Created Successfully", order);
        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to create order", Collections.emptyList());
        }
    }

    // Method to fetch a product by ID using POST
    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.GET_ORDER_BY_ID)
    public BaseApiResponse getOrderById(@RequestBody OrderRequest orderRequest) {
        try {
            Optional<Orders> order = orderService.getOrderById(orderRequest.getOrderId());
            if (order.isPresent()) {
                return new BaseApiResponse(SUCCESS_OK, 1, "Order fetched successfully", order.get());
            } else {
                return new BaseApiResponse(NOT_FOUND, 0, "Order not found", Collections.emptyList());
            }
        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to fetch order", Collections.emptyList());
        }
    }

    // Method to fetch all products using POST
    @PostMapping(REST_MAPPING_CONSTRAINT.DEFINED_API.GET_ORDERS)
    public BaseApiResponse getAllProducts() {
        try {
            List<Orders> orders = orderService.getAllOrders();  // Using List<Product>
            return new BaseApiResponse(SUCCESS_OK, 1, "Orders fetched successfully", orders);
        } catch (Exception e) {
            return new BaseApiResponse(INTERNAL_SERVER_ERROR, 0, "Failed to fetch orders", Collections.emptyList());
        }
    }
}
